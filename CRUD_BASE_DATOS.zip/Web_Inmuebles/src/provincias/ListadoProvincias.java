package provincias;

import javax.swing.*;
import java.awt.*;
import conexion.ConsultasBD;

public class ListadoProvincias extends JFrame {
    private JPanel listadoProvinciasPanel;
    private JTable table;

    public ListadoProvincias() {
        setTitle("LISTADO DE PROVINCIAS");
        setSize(600, 400);
        setLocationRelativeTo(null);

        listadoProvinciasPanel = new JPanel(new BorderLayout());
        listadoProvinciasPanel.setBackground(new Color(1, 26, 107));

        // Crear la tabla donde se cargarán los datos
        table = new JTable();

        // Lógica para obtener los datos de las provincias desde la base de datos y cargarlos en la tabla
        ConsultasBD consultasBD = new ConsultasBD();
        consultasBD.cargarProvincias(table);

        // Agregar la tabla a un JScrollPane y al panel
        JScrollPane scrollPane = new JScrollPane(table);
        listadoProvinciasPanel.add(scrollPane, BorderLayout.CENTER);

        // Agregar el panel al JFrame
        add(listadoProvinciasPanel);
        setVisible(true);
    }
}
