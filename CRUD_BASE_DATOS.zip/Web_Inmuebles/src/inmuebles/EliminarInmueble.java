package inmuebles;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import conexion.ConsultasBD;

public class EliminarInmueble extends JFrame {
    private JTextField txtIdInmueble;
    private JPanel eliminarInmueblePanel;

    public EliminarInmueble() {
        setTitle("Eliminar Inmueble");
        setSize(320, 230);
        setLayout(null); 

        
        eliminarInmueblePanel = new JPanel();
        eliminarInmueblePanel.setBackground(new Color(1, 26, 107));
        eliminarInmueblePanel.setBorder(new EmptyBorder(5, 5, 5, 5));
        eliminarInmueblePanel.setLayout(null);
        
        JLabel title = new JLabel("ELIMINAR INMUEBLE");
        title.setForeground(new Color(255, 255, 255));
        title.setBackground(new Color(0, 6, 128));
        title.setFont(new Font("MV Boli", Font.PLAIN, 18));
        title.setHorizontalAlignment(SwingConstants.CENTER);
        title.setBounds(50, 20, 210, 56);
        eliminarInmueblePanel.add(title);
        
        JLabel lblIdInmueble = new JLabel("Introduce el ID del inmueble:");
        lblIdInmueble.setBounds(60, 70, 300, 20);
        lblIdInmueble.setForeground(new Color(255, 255, 255));

        txtIdInmueble = new JTextField();
        txtIdInmueble.setBounds(60, 100, 100, 20);

        JButton btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(60, 130, 100, 30);

        eliminarInmueblePanel.add(lblIdInmueble);
        eliminarInmueblePanel.add(txtIdInmueble);
        eliminarInmueblePanel.add(btnEliminar);

        btnEliminar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                // Obtener el ID del inmueble a eliminar
                int idInmueble = Integer.parseInt(txtIdInmueble.getText());

                // Lógica para eliminar el inmueble de la base de datos
                ConsultasBD consultasBD = new ConsultasBD();
                consultasBD.eliminarInmueblePorID(idInmueble);

              
                dispose();
            }
        });
        
        setContentPane(eliminarInmueblePanel);
        setVisible(true);
    }
}
