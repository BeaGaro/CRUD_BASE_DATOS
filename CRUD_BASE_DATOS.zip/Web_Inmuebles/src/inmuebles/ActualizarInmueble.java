package inmuebles;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import conexion.*;

public class ActualizarInmueble extends JFrame {
	
	private JPanel actualizarPerfilPanel;
    private JTextField txtIdInmueble;
    private JTextField txtTipo;
    private JTextField txtMetros;
    private JTextField txtPrecio;
    private JTextField txtIdInmobiliaria;

    public ActualizarInmueble() {
        setTitle("Actualizar Inmueble");
        setSize(440, 360);
        setLayout(null); 
        
        actualizarPerfilPanel = new JPanel();
        actualizarPerfilPanel.setBackground(new Color(1, 26, 107));
        actualizarPerfilPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
        actualizarPerfilPanel.setLayout(null);
        
        setContentPane(actualizarPerfilPanel);
         
		JLabel titleMenu = new JLabel("ACTUALIZAR INMUEBLE");
		titleMenu.setForeground(new Color(255, 255, 255));
		titleMenu.setBackground(new Color(0, 6, 128));
		titleMenu.setFont(new Font("MV Boli", Font.PLAIN, 18));
		titleMenu.setHorizontalAlignment(SwingConstants.CENTER);
		titleMenu.setBounds(60, 30, 240, 56);
		actualizarPerfilPanel.add(titleMenu);
        
        JLabel lblIdInmueble = new JLabel("ID Inmueble:");
        lblIdInmueble.setBounds(40, 80, 100, 25);
        lblIdInmueble.setForeground(new Color(255, 255, 255));
        
        txtIdInmueble = new JTextField();
        txtIdInmueble.setBounds(140, 80, 200, 25);
        
        JLabel lblTipo = new JLabel("Tipo:");
        lblTipo.setBounds(40, 110, 100, 25);
        lblTipo.setForeground(new Color(255, 255, 255));
        
        txtTipo = new JTextField();
        txtTipo.setBounds(140, 110, 200, 25);
        
        JLabel lblMetros = new JLabel("Metros:");
        lblMetros.setBounds(40, 140, 100, 25);
        lblMetros.setForeground(new Color(255, 255, 255));
        
        txtMetros = new JTextField();
        txtMetros.setBounds(140, 140, 200, 25);
        
        JLabel lblPrecio = new JLabel("Precio:");
        lblPrecio.setBounds(40, 170, 100, 25);
        lblPrecio.setForeground(new Color(255, 255, 255));
        
        txtPrecio = new JTextField();
        txtPrecio.setBounds(140, 170, 200, 25);
        
        JLabel lblIdInmobiliaria = new JLabel("ID Inmobiliaria:");
        lblIdInmobiliaria.setBounds(40, 200, 100, 25);
        lblIdInmobiliaria.setForeground(new Color(255, 255, 255));
        
        txtIdInmobiliaria = new JTextField();
        txtIdInmobiliaria.setBounds(140, 200, 200, 25);

        JButton btnActualizar = new JButton("Actualizar");
        btnActualizar.setBounds(120, 240, 100, 30);

        // Agregar componentes al frame
        actualizarPerfilPanel.add(lblIdInmueble);
        actualizarPerfilPanel.add(txtIdInmueble);
        actualizarPerfilPanel.add(lblTipo);
        actualizarPerfilPanel.add(txtTipo);
        actualizarPerfilPanel.add(lblMetros);
        actualizarPerfilPanel.add(txtMetros);
        actualizarPerfilPanel.add(lblPrecio);
        actualizarPerfilPanel.add(txtPrecio);
        actualizarPerfilPanel.add(lblIdInmobiliaria);
        actualizarPerfilPanel.add(txtIdInmobiliaria);
        actualizarPerfilPanel.add(btnActualizar);

     
        btnActualizar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                // Obtener los datos ingresados por el usuario
                int idInmueble = Integer.parseInt(txtIdInmueble.getText());
                String tipo = txtTipo.getText();
                String metros = txtMetros.getText();
                int precio = Integer.parseInt(txtPrecio.getText());
                int idInmobiliaria = Integer.parseInt(txtIdInmobiliaria.getText());

                // Lógica para actualizar los datos en la base de datos (realizar la actualización en la tabla "inmuebles")
                ConsultasBD consultasBD = new ConsultasBD();
                consultasBD.actualizarInmueble(idInmueble, tipo, metros, precio, idInmobiliaria);

             
                dispose();
            }
        });

        setVisible(true);
    }
}
