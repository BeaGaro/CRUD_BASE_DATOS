package inmuebles;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import Gui.MenuPrincipal;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import conexion.ConsultasBD;

public class AñadirInmueble extends JFrame {
    private JTextField txtTipo;
    private JTextField txtMetros;
    private JTextField txtPrecio;
    private JTextField txtIdInmobiliaria;
    private JTextField txtIdProvincia;
    private JPanel añadirInmueblePanel;

    public AñadirInmueble() {
    	
        setTitle("AÑADIR INMUEBLE");
        setSize(420, 320);
        setLayout(null); 
        setLocationRelativeTo(null);
        
        int idUsuarioAutenticado = MenuPrincipal.getUsuarioAutenticado().getIdUsuario();
        
        añadirInmueblePanel = new JPanel();
        añadirInmueblePanel.setBackground(new Color(1, 26, 107));
        añadirInmueblePanel.setBorder(new EmptyBorder(5, 5, 5, 5));
        añadirInmueblePanel.setLayout(null);
        
        // Crear un JLabel para mostrar el ID del usuario autenticado
        JLabel lblIdUsuario = new JLabel("Su ID Usuario: " + idUsuarioAutenticado);
        lblIdUsuario.setForeground(Color.WHITE);
        lblIdUsuario.setFont(new Font("Arial", Font.PLAIN, 12));
        lblIdUsuario.setBounds(10, 10, 100, 20); 
        añadirInmueblePanel.add(lblIdUsuario);
        
        
        
        JLabel titleMenu = new JLabel("AÑADIR INMUEBLE");
		titleMenu.setForeground(new Color(255, 255, 255));
		titleMenu.setBackground(new Color(0, 6, 128));
		titleMenu.setFont(new Font("MV Boli", Font.PLAIN, 18));
		titleMenu.setHorizontalAlignment(SwingConstants.CENTER);
		titleMenu.setBounds(50, 30, 210, 56);
		añadirInmueblePanel.add(titleMenu);
        

        JLabel lblTipo = new JLabel("Tipo:");
        lblTipo.setBounds(20, 80, 100, 25);
        lblTipo.setForeground(new Color(255, 255, 255));
        
        txtTipo = new JTextField();
        txtTipo.setBounds(120, 80, 200, 25);
        
        JLabel lblMetros = new JLabel("Metros:");
        lblMetros.setBounds(20, 110, 100, 25);
        lblMetros.setForeground(new Color(255, 255, 255));
        
        txtMetros = new JTextField();
        txtMetros.setBounds(120, 110, 200, 25);
        
        JLabel lblPrecio = new JLabel("Precio:");
        lblPrecio.setBounds(20, 140, 100, 25);
        lblPrecio.setForeground(new Color(255, 255, 255));
        
        txtPrecio = new JTextField();
        txtPrecio.setBounds(120, 140, 200, 25);
        
        JLabel lblIdInmobiliaria = new JLabel("ID Inmobiliaria:");
        lblIdInmobiliaria.setBounds(20, 170, 100, 25);
        lblIdInmobiliaria.setForeground(new Color(255, 255, 255));
        
        txtIdInmobiliaria = new JTextField();
        txtIdInmobiliaria.setBounds(120, 170, 200, 25);
        
        JLabel lblIdProvincia = new JLabel("Provincia:");
        lblIdProvincia.setBounds(20, 200, 100, 25);
        lblIdProvincia.setForeground(new Color(255, 255, 255));
        
        txtIdProvincia = new JTextField();
        txtIdProvincia.setBounds(120, 200, 200, 25);

        JButton btnGuardar = new JButton("Guardar");
        btnGuardar.setBounds(120, 230, 100, 30);

        // Agregar componentes al panel
        añadirInmueblePanel.add(lblTipo);
        añadirInmueblePanel.add(txtTipo);
        añadirInmueblePanel.add(lblMetros);
        añadirInmueblePanel. add(txtMetros);
        añadirInmueblePanel.add(lblPrecio);
        añadirInmueblePanel.add(txtPrecio);
        añadirInmueblePanel.add(lblIdInmobiliaria);
        añadirInmueblePanel.add(txtIdInmobiliaria);
        añadirInmueblePanel.add(lblIdProvincia);
        añadirInmueblePanel.add(txtIdProvincia);
        añadirInmueblePanel.add(btnGuardar);

      
        btnGuardar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                // Obtener los datos ingresados por el usuario
                String tipo = txtTipo.getText();
                String metros = txtMetros.getText();
                int precio = Integer.parseInt(txtPrecio.getText());
                int idInmobiliaria = Integer.parseInt(txtIdInmobiliaria.getText());
                String idProvincia = txtIdProvincia.getText();

                // Lógica para guardar los datos en la base de datos (realizar la inserción en la tabla "inmuebles")
                ConsultasBD consultasBD = new ConsultasBD();
                consultasBD.agregarInmueble(tipo, metros, precio, idInmobiliaria, idProvincia);
               
                dispose();
            }
        });
        
        
        setContentPane(añadirInmueblePanel);
        setVisible(true);
    }
}
