package inmuebles;

import javax.swing.*;
import java.awt.*;
import conexion.ConsultasBD;

public class ListadoInmuebles extends JFrame {
    private JPanel listadoInmueblesPanel;
    private JTable table;

    public ListadoInmuebles() {
        setTitle("LISTADO DE INMUEBLES");
        setSize(600, 400);
        setLocationRelativeTo(null);

        listadoInmueblesPanel = new JPanel(new BorderLayout());
        listadoInmueblesPanel.setBackground(new Color(1, 26, 107)); 

        // Crear la JTable para mostrar los datos
        table = new JTable();

        // Obtener los datos de la base de datos y cargarlos en la tabla
        ConsultasBD.cargarInmuebles(table);

        // Agregar la tabla al panel
        JScrollPane scrollPane = new JScrollPane(table);
        table.setPreferredScrollableViewportSize(new Dimension(500, 350)); 
        table.setFillsViewportHeight(true);
        listadoInmueblesPanel.add(scrollPane, BorderLayout.CENTER);

        // Agregar el panel al JFrame
        add(listadoInmueblesPanel);
        setVisible(true);
    }
}
