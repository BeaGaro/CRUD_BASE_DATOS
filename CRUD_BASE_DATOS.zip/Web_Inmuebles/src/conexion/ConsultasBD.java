package conexion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import usuarios.Usuario;
import Gui.MenuPrincipal;

public class ConsultasBD {

	
	//              SELECTS                   //
	
	
	//  LISTADO DE INMUEBLES //
    public static void cargarInmuebles(JTable table) {
        try {
            Connection conn = ConexionBD.obtenerConexion();

            String query = "SELECT * FROM inmuebles";
            PreparedStatement pstmt = conn.prepareStatement(query);
            ResultSet rs = pstmt.executeQuery();

            // Crear modelo de tabla
            DefaultTableModel tableInmuebles = new DefaultTableModel();
            tableInmuebles.addColumn("ID Inmueble");
            tableInmuebles.addColumn("Tipo");
            tableInmuebles.addColumn("Metros");
            tableInmuebles.addColumn("Precio");
            tableInmuebles.addColumn("ID Inmobiliaria");
            tableInmuebles.addColumn("ID Provincia");

            // Llenar la tabla con los datos de la consulta
            while (rs.next()) {
                tableInmuebles.addRow(new Object[]{
                    rs.getInt("id_inmueble"),
                    rs.getString("tipo"),
                    rs.getString("metros"),
                    rs.getInt("precio"),
                    rs.getInt("id_inmobiliaria"),
                    rs.getInt("id_provincia")
                });
            }

            // Asignar el modelo de tabla a la JTable proporcionada
            table.setModel(tableInmuebles);

            rs.close();
            pstmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al cargar los datos de inmuebles desde la base de datos.");
        }
    }
    
    //   LISTADO DE INMOBILIARIAS   //
    public void cargarInmobiliarias(JTable table) {
        try {
        	 Connection conn = ConexionBD.obtenerConexion();

            String query = "SELECT * FROM inmobiliarias";
            PreparedStatement pstmt = conn.prepareStatement(query);
            ResultSet rs = pstmt.executeQuery();

            // Crear modelo de tabla
            DefaultTableModel tableInmobiliarias = new DefaultTableModel();
            tableInmobiliarias.addColumn("ID Inmobiliaria");
            tableInmobiliarias.addColumn("Nombre");
            tableInmobiliarias.addColumn("Email");
            tableInmobiliarias.addColumn("ID Usuario");

            // Llenar la tabla con los datos de la consulta
            while (rs.next()) {
                tableInmobiliarias.addRow(new Object[]{
                        rs.getInt("id_inmobiliaria"),
                        rs.getString("nombre"),
                        rs.getString("email"),
                        rs.getInt("id_usuario")
                });
            }

            // Crear la tabla y agregarla al panel
            table.setModel(tableInmobiliarias);
           

            rs.close();
            pstmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al cargar los datos de inmobiliarias desde la base de datos.");
        }
    }
    
    
    //        LISTADO DE PROVINCIAS        //
    public static void cargarProvincias(JTable table) {
        try {
            Connection conn = ConexionBD.obtenerConexion();

            String query = "SELECT * FROM provincias";
            PreparedStatement pstmt = conn.prepareStatement(query);
            ResultSet rs = pstmt.executeQuery();

            // Crear modelo de tabla
            DefaultTableModel tableProvincias = new DefaultTableModel();
            tableProvincias.addColumn("ID Provincia");
            tableProvincias.addColumn("Nombre");

            // Llenar la tabla con los datos de la consulta
            while (rs.next()) {
                tableProvincias.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("nombre")
                });
            }

            // Asignar el modelo de tabla a la JTable proporcionada
            table.setModel(tableProvincias);

            rs.close();
            pstmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al cargar los datos de provincias desde la base de datos.");
        }
    }
      
    
      //       LISTADO DE USUARIOS       //
    public void cargarUsuarios(JTable table) {
        try {
            Connection conn = ConexionBD.obtenerConexion();

            String query = "SELECT id_usuario, nombre, rol FROM usuarios";
            PreparedStatement pstmt = conn.prepareStatement(query);
            ResultSet rs = pstmt.executeQuery();

            // Crear modelo de tabla
            DefaultTableModel tableUsuarios = new DefaultTableModel();
            tableUsuarios.addColumn("ID Usuario");
            tableUsuarios.addColumn("Nombre");
            tableUsuarios.addColumn("Rol");

            // Llenar la tabla con los datos de la consulta
            while (rs.next()) {
                tableUsuarios.addRow(new Object[]{
                    rs.getInt("id_usuario"),
                    rs.getString("nombre"),
                    rs.getString("rol")
                });
            }

            // Asignar el modelo de tabla a la JTable proporcionada
            table.setModel(tableUsuarios);

            rs.close();
            pstmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al cargar los datos de usuarios desde la base de datos.");
        }
    }
    
    
    
    
    //   COMPRUEBA SI EL ID DE USUARIO QUE HA INICIADO SESION TIENE RELACION CON LA INMOBILIARIA QUE SOLICITA ACUTALIZAR    //
    public static boolean tieneRelacionUsuarioInmobiliaria(int idUsuario, int idInmobiliaria) {
        try {
            Connection conn = ConexionBD.obtenerConexion();

            String query = "SELECT id_usuario FROM inmobiliarias WHERE id_inmobiliaria = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, idInmobiliaria);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                int idUsuarioInmobiliaria = rs.getInt("id_usuario");
                return idUsuarioInmobiliaria == idUsuario;
            }

            rs.close();
            pstmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al verificar la asociación de la inmobiliaria con el usuario.");
        }

        return false;
    }

      
    //  VERIFICA SI YA HAY UNA INMOBILIARIA CON ESE NOMBRE EN LA BASE DE DATOS //
    public static boolean existeInmobiliariaConNombre(String nombre) {
        boolean existe = false;
        try {
            Connection conn = ConexionBD.obtenerConexion();

            String query = "SELECT COUNT(*) AS count FROM inmobiliarias WHERE nombre = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, nombre);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                int count = rs.getInt("count");
                existe = count > 0;
            }

            rs.close();
            pstmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al verificar la existencia de la inmobiliaria en la base de datos.");
        }
        return existe;
    }

    
    //    COMPRUEBA SI EL ID DE LA INMOBILIARIA EXISTE EN LA BASE DE DATOS
    public static boolean existeInmobiliariaConID(int idInmobiliaria) {
        try {
            Connection conn = ConexionBD.obtenerConexion();

            String query = "SELECT id_inmobiliaria FROM inmobiliarias WHERE id_inmobiliaria = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, idInmobiliaria);
            ResultSet rs = pstmt.executeQuery();

            boolean existe = rs.next();

            rs.close();
            pstmt.close();
            conn.close();

            return existe;
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al verificar la existencia de la inmobiliaria en la base de datos.");
        }

        return false;
    }
    
    
    
    
    //                  UPDATES               //
    
    
    //   ACTUALIZA INMUEBLE   //
    public void actualizarInmueble(int idInmueble, String tipo, String metros, int precio, int idInmobiliaria) {
        try {
        	Connection conn = ConexionBD.obtenerConexion();

            String query = "UPDATE inmuebles SET tipo=?, metros=?, precio=?, id_inmobiliaria=? WHERE id_inmueble=?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, tipo);
            pstmt.setString(2, metros);
            pstmt.setInt(3, precio);
            pstmt.setInt(4, idInmobiliaria);
            pstmt.setInt(5, idInmueble);

            // Ejecutar la consulta de actualización
            pstmt.executeUpdate();

            pstmt.close();
            conn.close();
            JOptionPane.showMessageDialog(null, "Inmueble actualizado correctamente.");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al actualizar el inmueble en la base de datos.");
        }
    }
    
    
    //   ACTUALIZAR DATOS DE USUARIO CON PARAMETROS DE USUARIO QUE HA INICIADO SESION  //
    public static void actualizarDatos(int idUsuarioAutenticado, String nuevoNombre, String nuevaContraseña) {
        try {
            Connection conn = ConexionBD.obtenerConexion();

            String query = "UPDATE usuarios SET nombre = ?, contraseña = ? WHERE id_usuario = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, nuevoNombre);
            pstmt.setString(2, nuevaContraseña);
            pstmt.setInt(3, idUsuarioAutenticado);

            int rowsAffected = pstmt.executeUpdate();

            pstmt.close();
            conn.close();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Datos de usuario actualizados correctamente.");
            } else {
                JOptionPane.showMessageDialog(null, "No se encontró ningún usuario con el ID especificado.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al actualizar los datos de usuario en la base de datos.");
        }
    }

    
    //    ACTUALIZAR INMOBILIARIA COMPROBANDO SI TIENE RELACION CON EL USUARIO QUE HA INICIADO SESION   //
    public static void actualizarInmobiliaria(int idInmobiliaria, String nombre, String email) {
        try {
            Connection conn = ConexionBD.obtenerConexion();

            // Verificamos la relación antes de la actualización
            if (tieneRelacionUsuarioInmobiliaria(MenuPrincipal.getUsuarioAutenticado().getIdUsuario(), idInmobiliaria)) {
                String query = "UPDATE inmobiliarias SET nombre = ?, email = ? WHERE id_inmobiliaria = ?";
                PreparedStatement pstmt = conn.prepareStatement(query);
                pstmt.setString(1, nombre);
                pstmt.setString(2, email);
                pstmt.setInt(3, idInmobiliaria);

                pstmt.executeUpdate();

                pstmt.close();
                conn.close();
                JOptionPane.showMessageDialog(null, "Inmobiliaria actualizada correctamente.");
            } else {
                JOptionPane.showMessageDialog(null, "Lo siento, ha ocurrido un error.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al actualizar la inmobiliaria en la base de datos.");
        }
    }


    
    
    //                 DELETES              //
      
    
    //    ELIMINAR INMUEBLE   //
    public void eliminarInmueblePorID(int idInmueble) {
        try {
        	Connection conn = ConexionBD.obtenerConexion();

            String query = "DELETE FROM inmuebles WHERE id_inmueble = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, idInmueble);

            // Ejecutar la consulta de eliminación
            int filasEliminadas = pstmt.executeUpdate();

            if (filasEliminadas > 0) {
                JOptionPane.showMessageDialog(null, "El inmueble con ID " + idInmueble + " ha sido eliminado correctamente.");
            } else {
                JOptionPane.showMessageDialog(null, "No se encontró ningún inmueble con ID " + idInmueble + ".");
            }

            pstmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al eliminar el inmueble desde la base de datos.");
        }
    }
    
    
    // ELIMINAR INMOBILIARIA //
    public void eliminarInmobiliariaPorID(int idInmobiliaria) {
        try {
            Connection conn = ConexionBD.obtenerConexion();

            String query = "DELETE FROM inmobiliarias WHERE id_inmobiliaria = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, idInmobiliaria);

            // Ejecutar la consulta de eliminación
            int filasEliminadas = pstmt.executeUpdate();

            if (filasEliminadas > 0) {
                JOptionPane.showMessageDialog(null, "La inmobiliaria con ID " + idInmobiliaria + " ha sido eliminada correctamente.");
            } else {
                JOptionPane.showMessageDialog(null, "No se encontró ninguna inmobiliaria con ID " + idInmobiliaria + ".");
            }

            pstmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al eliminar la inmobiliaria desde la base de datos.");
        }
    }
     
    //                   INSERTS                       //
    
    
    
    //    AGREGAR INMUEBLE  //
    public void agregarInmueble(String tipo, String metros, int precio, int idInmobiliaria, String nombreProvincia) {
        try {
            Connection conn = ConexionBD.obtenerConexion();

            // Consulta para obtener el ID de la provincia
            String queryProvincia = "SELECT id FROM provincias WHERE nombre = ?";
            PreparedStatement pstmtProvincia = conn.prepareStatement(queryProvincia);
            pstmtProvincia.setString(1, nombreProvincia);
            ResultSet rsProvincia = pstmtProvincia.executeQuery();

            int idProvincia = -1; // Valor predeterminado en caso de que no se encuentre la provincia
            if (rsProvincia.next()) {
                idProvincia = rsProvincia.getInt("id");
            } else {
                JOptionPane.showMessageDialog(null, "La provincia ingresada no se encuentra en la base de datos.");
                return;
            }

            rsProvincia.close();
            pstmtProvincia.close();

            // Verificar si el ID de la inmobiliaria existe
            if (!existeInmobiliariaConID(idInmobiliaria)) {
                JOptionPane.showMessageDialog(null, "El ID de la inmobiliaria no es correcto.");
                return;
            }

            // Consulta para insertar el inmueble con el ID de la provincia obtenido
            String query = "INSERT INTO inmuebles (tipo, metros, precio, id_inmobiliaria, id_provincia) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, tipo);
            pstmt.setString(2, metros);
            pstmt.setInt(3, precio);
            pstmt.setInt(4, idInmobiliaria);
            pstmt.setInt(5, idProvincia);

            // Ejecutar la consulta de inserción
            pstmt.executeUpdate();

            pstmt.close();
            conn.close();
            JOptionPane.showMessageDialog(null, "Nuevo inmueble agregado correctamente.");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al agregar el inmueble a la base de datos.");
        }
    }


    
    
    // AGREGAR INMOBILIARIA  //
    public void agregarInmobiliaria(String nombre, String email, int idUsuario) {
        try {
            // Verificar si ya existe una inmobiliaria con el nombre proporcionado
            if (existeInmobiliariaConNombre(nombre)) {
                JOptionPane.showMessageDialog(null, "Ya existe una inmobiliaria con ese nombre.");
                return; // Salir del método si ya existe una inmobiliaria con ese nombre
            }

            Connection conn = ConexionBD.obtenerConexion();

            // Consulta para insertar una nueva inmobiliaria en la tabla
            String query = "INSERT INTO inmobiliarias (nombre, email, id_usuario) VALUES (?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, nombre);
            pstmt.setString(2, email);
            pstmt.setInt(3, idUsuario);

            // Ejecutar la consulta de inserción
            pstmt.executeUpdate();

            pstmt.close();
            conn.close();
            JOptionPane.showMessageDialog(null, "Nueva inmobiliaria agregada correctamente.");
        } catch (java.sql.SQLIntegrityConstraintViolationException ex) {
            JOptionPane.showMessageDialog(null, "El ID de usuario proporcionado no existe en la base de datos.",
                    "Error al agregar inmobiliaria", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al agregar la inmobiliaria a la base de datos.",
                    "Error SQL", JOptionPane.ERROR_MESSAGE);
        }
    }


    
}
