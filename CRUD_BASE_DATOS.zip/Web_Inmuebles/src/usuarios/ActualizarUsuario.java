package usuarios;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import conexion.ConsultasBD;
import Gui.MenuPrincipal;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ActualizarUsuario extends JFrame {
	
	private JPanel actualizarPerfilPanel;
    private JTextField txtNuevoNombre;
    private JPasswordField txtNuevaContraseña;

    public ActualizarUsuario() {
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(320, 240);
        setLocationRelativeTo(null);
        setTitle("ACTUALIZAR USUARIO");
        
        int idUsuarioAutenticado = MenuPrincipal.getUsuarioAutenticado().getIdUsuario();
        
        actualizarPerfilPanel = new JPanel();
        actualizarPerfilPanel.setBackground(new Color(1, 26, 107));
        actualizarPerfilPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
        actualizarPerfilPanel.setLayout(null);

        // Crear un JLabel para mostrar el ID del usuario autenticado
        JLabel lblIdUsuario = new JLabel("Su ID Usuario: " + idUsuarioAutenticado);
        lblIdUsuario.setForeground(Color.WHITE);
        lblIdUsuario.setFont(new Font("Arial", Font.PLAIN, 12));
        lblIdUsuario.setBounds(10, 10, 100, 20); 
        actualizarPerfilPanel.add(lblIdUsuario);
        
        JLabel titleMenu = new JLabel("ACTUALIZAR USUARIO");
		titleMenu.setForeground(new Color(255, 255, 255));
		titleMenu.setBackground(new Color(0, 6, 128));
		titleMenu.setFont(new Font("MV Boli", Font.PLAIN, 18));
		titleMenu.setHorizontalAlignment(SwingConstants.CENTER);
		titleMenu.setBounds(50, 30, 210, 56);
		actualizarPerfilPanel.add(titleMenu);

        JLabel lblNuevoNombre = new JLabel("Nuevo Nombre:");   
        lblNuevoNombre.setBounds(40, 80, 100, 25);
        lblNuevoNombre.setForeground(new Color(255, 255, 255));
        
        txtNuevoNombre = new JTextField();
        txtNuevoNombre.setBounds(160, 80, 100, 25);
        
        
        JLabel lblNuevaContraseña = new JLabel("Nueva Contraseña:");
        lblNuevaContraseña.setBounds(40, 120, 100, 25);
        lblNuevaContraseña.setForeground(new Color(255, 255, 255));
        
        txtNuevaContraseña = new JPasswordField();
        txtNuevaContraseña.setBounds(160, 120, 100, 25);
        
        JButton btnActualizar = new JButton("Actualizar");
        btnActualizar.setBounds(160, 160, 100, 25);

        actualizarPerfilPanel.add(lblNuevoNombre);
        actualizarPerfilPanel.add(txtNuevoNombre);
        actualizarPerfilPanel.add(lblNuevaContraseña);
        actualizarPerfilPanel.add(txtNuevaContraseña);
        actualizarPerfilPanel.add(btnActualizar);

        btnActualizar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nuevoNombre = txtNuevoNombre.getText();
                String nuevaContraseña = new String(txtNuevaContraseña.getPassword());

                // Lógica para actualizar el nombre y la contraseña del usuario en la base de datos
                ConsultasBD consultaBD = new ConsultasBD();
                ConsultasBD.actualizarDatos(idUsuarioAutenticado, nuevoNombre, nuevaContraseña);
                // Cierra la ventana después de actualizar
                dispose();
            }
        });

        setContentPane(actualizarPerfilPanel);
        setVisible(true);
    }
}
