package usuarios;


import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import conexion.ConsultasBD;

public class ListadoUsuarios extends JFrame {
    private JPanel listadoUsuariosPanel;
    private JTable table;

    public ListadoUsuarios() {
        setTitle("LISTADO DE USUARIOS");
        setSize(600, 400);
        setLocationRelativeTo(null);

        listadoUsuariosPanel = new JPanel(new BorderLayout());
        listadoUsuariosPanel.setBackground(new Color(1, 26, 107)); 
        
        // Crear la tabla para mostrar los datos
        table = new JTable();

        // Lógica para obtener los datos de los usuarios desde la base de datos y cargarlos en la tabla
        ConsultasBD consultasBD = new ConsultasBD();
        consultasBD.cargarUsuarios(table);

        // Agregar la tabla a un JScrollPane y al panel
        JScrollPane scrollPane = new JScrollPane(table);
        listadoUsuariosPanel.add(scrollPane, BorderLayout.CENTER);

        // Agregar el panel al JFrame
        add(listadoUsuariosPanel);
        setVisible(true);
    }

}
