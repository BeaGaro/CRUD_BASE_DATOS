package Gui;

import java.awt.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import usuarios.Usuario;

public class MenuPrincipal extends JFrame {

	private JPanel loginUsuarioPanel;	// login de usuario
	
    private JTextField txtNombre;
    private JTextField txtPass;
    private static Usuario usuarioAutenticado;

    public static Usuario getUsuarioAutenticado() {
        return usuarioAutenticado;
    }

    public static void setUsuarioAutenticado(Usuario usuario) {
        usuarioAutenticado = usuario;
    }
    
	public MenuPrincipal() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(450, 310);
		setLocationRelativeTo(null);
		loginUsuarioPanel = new JPanel();
		loginUsuarioPanel.setBackground(new Color(1, 26, 107));
		loginUsuarioPanel.setBorder(new EmptyBorder(5, 5, 5, 5));		
  
		
	//   ELEMENTOS LOGIN PANEL    //
		
		setContentPane(loginUsuarioPanel);
		loginUsuarioPanel.setLayout(null);
		
		JLabel titleMenu = new JLabel("Login");
		titleMenu.setForeground(new Color(255, 255, 255));
		titleMenu.setBackground(new Color(0, 6, 128));
		titleMenu.setFont(new Font("MV Boli", Font.PLAIN, 34));
		titleMenu.setHorizontalAlignment(SwingConstants.CENTER);
		titleMenu.setBounds(102, 31, 172, 56);
		loginUsuarioPanel.add(titleMenu);		
        
		JLabel lblNombre = new JLabel("Nombre:");
		lblNombre.setBounds(70, 100, 100, 30); // Establecer coordenadas y dimensiones
		lblNombre.setForeground(new Color(255, 255, 255));
		loginUsuarioPanel.add(lblNombre);

		JTextField txtNombre = new JTextField(20);
		txtNombre.setBounds(170, 100, 200, 30); // Establecer coordenadas y dimensiones
		loginUsuarioPanel.add(this.txtNombre=txtNombre);
        	        
	    JLabel lblPass = new JLabel("Contraseña:");
	    lblPass.setBounds(70, 150, 300, 30);
	    lblPass.setForeground(new Color(255, 255, 255));
	    loginUsuarioPanel.add(lblPass);
	    
	    JPasswordField txtPass = new JPasswordField(20); // Cambio de JTextField a JPasswordField
	    txtPass.setBounds(170, 150, 200, 30);
	    loginUsuarioPanel.add(this.txtPass = txtPass);
		
		
//  BOTON   ENTRAR   //
		
		JButton btnEntrar = new JButton("ENTRAR");
		btnEntrar.setBounds(170, 200, 200, 40);
		btnEntrar.setFocusable(false);
		btnEntrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				comprobarUsuario();
			}
		});
		loginUsuarioPanel.add(btnEntrar);
				
	}
	
	
	// MÉTODOS RELACIONADOS CON EL LOGIN DE USUARIO   //
	
	// Método para comprobar el usuario y su rol   //
    private void comprobarUsuario() {
        
        String nombreUsuario = txtNombre.getText();
        String contraseñaUsuario = txtPass.getText();

        if (validarUsuario(nombreUsuario, contraseñaUsuario)) {
            String rolUsuario = obtenerRolUsuario(nombreUsuario);
            Usuario usuario = obtenerUsuario(nombreUsuario);
            setUsuarioAutenticado(usuario);
            
            if ("administrador".equals(rolUsuario)) {
                // Cerrar la ventana actual (Interfaz)
                this.dispose();

                MenuAdministrador adminMenu = new MenuAdministrador();  // Abrir ventana Menu Administrador
                adminMenu.setVisible(true);               
            } 
            
            else if ("usuario".equals(rolUsuario)) {
                // Cerrar la ventana actual (Interfaz)
                this.dispose();
                
                MenuUsuario userMenu = new MenuUsuario();  // Abrir la ventana del menú de usuario
                userMenu.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(null, "Rol desconocido");     // Si el rol no es reconocido, muestra un mensaje de error           
            }
        } else {
            JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos"); // Si el usuario o la contraseña son incorrectos, muestra un mensaje de error
        }
    }
    
    
    // MÉTODO PARA OBTENER EL USUARIO QUE HA INICIADO SESION   //
    private Usuario obtenerUsuario(String nombreUsuario) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Usuario usuario = null;

        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/found_home", "root", "");

            String consulta = "SELECT * FROM usuarios WHERE nombre = ?";
            pstmt = conn.prepareStatement(consulta);
            pstmt.setString(1, nombreUsuario);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                int id_usuario = rs.getInt("id_usuario");
                String nombre = rs.getString("nombre");
                String contraseña = rs.getString("contraseña");
                String rol = rs.getString("rol");
                
                // Crear un objeto Usuario con la información obtenida de la base de datos
                usuario = new Usuario(id_usuario, nombre, contraseña, rol);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al intentar obtener el usuario de la base de datos: " + e.getMessage(), "Error de base de datos", JOptionPane.ERROR_MESSAGE);
        } finally {
            
        	 try {
                 if (rs != null) rs.close();
                 if (pstmt != null) pstmt.close();
                 if (conn != null) conn.close();
             } catch (SQLException e) {
                 e.printStackTrace();
             }
        }

        return usuario;
    }

    
//   VERIFICA SI EXISTE EL USUARIO EN LA BASE DE DATOS Y SI EL NOMBRE Y CONTRASEÑA SON CORRECTOS   //
		 private boolean validarUsuario(String nombreUsuario, String contraseñaUsuario) {
		        Connection conn = null;
		        PreparedStatement pstmt = null;
		        ResultSet rs = null;
		        boolean usuarioValido = false;

		        try {
		            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/found_home", "root", "");

		            String consulta = "SELECT * FROM usuarios WHERE nombre = ? AND contraseña = ?";
		            pstmt = conn.prepareStatement(consulta);
		            pstmt.setString(1, nombreUsuario);
		            pstmt.setString(2, contraseñaUsuario);
		            rs = pstmt.executeQuery();

		            usuarioValido = rs.next(); // Si hay un resultado, el usuario es válido

		        } catch (SQLException e) {
		            e.printStackTrace();
		        } finally {
		            try {
		                if (rs != null) rs.close();
		                if (pstmt != null) pstmt.close();
		                if (conn != null) conn.close();
		            } catch (SQLException e) {
		                e.printStackTrace();
		            }
		        }

		        return usuarioValido;
		    }

		    // Método para obtener el rol del usuario desde la base de datos
		    private String obtenerRolUsuario(String nombreUsuario) {
		        Connection conn = null;
		        PreparedStatement pstmt = null;
		        ResultSet rs = null;
		        String rol = null;

		        try {
		            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/found_home", "root", "");

		            String consulta = "SELECT rol FROM usuarios WHERE nombre = ?";
		            pstmt = conn.prepareStatement(consulta);
		            pstmt.setString(1, nombreUsuario);
		            rs = pstmt.executeQuery();

		            if (rs.next()) {
		                rol = rs.getString("rol");
		            }

		        } catch (SQLException e) {
		            e.printStackTrace();
		        } finally {
		            try {
		                if (rs != null) rs.close();
		                if (pstmt != null) pstmt.close();
		                if (conn != null) conn.close();
		            } catch (SQLException e) {
		                e.printStackTrace();
		            }
		        }

		        return rol;
		    }

		

    }


    

