package Gui;
import java.awt.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import inmobiliarias.AñadirInmobiliaria;
import inmobiliarias.ListadoInmobiliarias;
import inmuebles.ActualizarInmueble;
import inmuebles.AñadirInmueble;
import inmuebles.EliminarInmueble;
import inmuebles.ListadoInmuebles;
import provincias.ListadoProvincias;
import usuarios.ListadoUsuarios;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class MenuAdministrador extends JFrame {
	
	private JPanel menuAdminPanel;

    public MenuAdministrador() {
    	
        // Configuración del JFrame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 360);
        setLocationRelativeTo(null);
        
        int idUsuarioAutenticado = MenuPrincipal.getUsuarioAutenticado().getIdUsuario();

        // Inicialización y configuración de componentes
        menuAdminPanel = new JPanel();
        menuAdminPanel.setBackground(new Color(1, 26, 107));
        menuAdminPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
        menuAdminPanel.setLayout(null);
        
        // Crear un JLabel para mostrar el ID del usuario autenticado
        JLabel lblIdUsuario = new JLabel("Su ID Usuario: " + idUsuarioAutenticado);
        lblIdUsuario.setForeground(Color.WHITE);
        lblIdUsuario.setFont(new Font("Arial", Font.PLAIN, 12));
        lblIdUsuario.setBounds(10, 10, 100, 20); 
        menuAdminPanel.add(lblIdUsuario);
        
        
		JLabel titleMenu = new JLabel("MENU ADMINISTRADOR");
		titleMenu.setForeground(new Color(255, 255, 255));
		titleMenu.setBackground(new Color(0, 6, 128));
		titleMenu.setFont(new Font("MV Boli", Font.PLAIN, 22));
		titleMenu.setHorizontalAlignment(SwingConstants.CENTER);
		titleMenu.setBounds(70, 20, 300, 60);
		menuAdminPanel.add(titleMenu);
        
        
        JButton btnVerUsuarios = new JButton("Listado de usuarios");
        btnVerUsuarios.setBounds(50, 100, 200, 40);
        btnVerUsuarios.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	 ListadoUsuarios listadoUsuariosFrame = new ListadoUsuarios();
            	 listadoUsuariosFrame.setVisible(true);
            }
        });
        menuAdminPanel.add(btnVerUsuarios);
        
        
        JButton btnVerListado = new JButton("Listado de inmuebles");
        btnVerListado.setBounds(50, 150, 200, 40);
        btnVerListado.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	 ListadoInmuebles listadoInmueblesFrame = new ListadoInmuebles();
                 listadoInmueblesFrame.setVisible(true);
            }
        });
        menuAdminPanel.add(btnVerListado);
        
        
        JButton btnListaInmobiliaria = new JButton("Listado inmobiliarias");
        btnListaInmobiliaria.setBounds(50, 200, 200, 40);
        btnListaInmobiliaria.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	 ListadoInmobiliarias listadoInmobiliarias = new ListadoInmobiliarias();
                 listadoInmobiliarias.setVisible(true);
            }
        });
        menuAdminPanel.add(btnListaInmobiliaria);
        
        JButton btnListaProvincias = new JButton("Listado provincias");
        btnListaProvincias.setBounds(50, 250, 200, 40);
        btnListaProvincias.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	 ListadoProvincias listadoProvincias = new ListadoProvincias();
            	 listadoProvincias.setVisible(true);
            }
        });
        menuAdminPanel.add(btnListaProvincias);
        
        
        
        
        JButton btnAnadirInmobiliaria = new JButton("Añadir inmobiliaria");
        btnAnadirInmobiliaria.setBounds(260, 100, 200, 40);
        btnAnadirInmobiliaria.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	ListadoUsuarios listadoUsuariosFrame = new ListadoUsuarios();
           	 	listadoUsuariosFrame.setVisible(true);
             	AñadirInmobiliaria ventanaAñadirInmobiliaria = new AñadirInmobiliaria();
             	ventanaAñadirInmobiliaria.setVisible(true);
            }
        });
        menuAdminPanel.add(btnAnadirInmobiliaria);
        
        
        JButton btnAnadirInmueble = new JButton("Añadir inmueble");
        btnAnadirInmueble.setBounds(260, 150, 200, 40);
        btnAnadirInmueble.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	 ListadoInmobiliarias listadoInmobiliarias = new ListadoInmobiliarias();
                 listadoInmobiliarias.setVisible(true);
            	AñadirInmueble ventanaAñadirInmueble = new AñadirInmueble();
                ventanaAñadirInmueble.setVisible(true);
            }
        });
        menuAdminPanel.add(btnAnadirInmueble);

        
        JButton btnActualizarInmueble = new JButton("Actualizar inmueble");
        btnActualizarInmueble.setBounds(260, 200, 200, 40);
        btnActualizarInmueble.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	 ListadoInmuebles listadoInmueblesFrame = new ListadoInmuebles();
                 listadoInmueblesFrame.setVisible(true);
            	  ActualizarInmueble ventanaActualizarInmueble = new ActualizarInmueble();
                  ventanaActualizarInmueble.setVisible(true);
                 
            }
        });
        menuAdminPanel.add(btnActualizarInmueble);
        
        
        JButton btnEliminarInmueble = new JButton("Eliminar inmueble");
        btnEliminarInmueble.setBounds(260, 250, 200, 40);
        btnEliminarInmueble.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	  EliminarInmueble ventanaEliminarInmueble = new EliminarInmueble();
                  ventanaEliminarInmueble.setVisible(true);
                  ListadoInmuebles listadoInmueblesFrame = new ListadoInmuebles();
                  listadoInmueblesFrame.setVisible(true);
            }
        });
        menuAdminPanel.add(btnEliminarInmueble);
        
     // Agregar componentes al panel adminPanel
        setContentPane(menuAdminPanel);

        // Establecer el panel como contenido del JFrame
        setContentPane(menuAdminPanel);
    }
    
}
