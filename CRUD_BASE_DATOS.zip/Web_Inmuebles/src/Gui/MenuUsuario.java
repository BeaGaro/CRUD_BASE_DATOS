package Gui;

import java.awt.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import inmuebles.ListadoInmuebles;
import inmuebles.ActualizarInmueble;
import usuarios.ActualizarUsuario;
import inmobiliarias.ListadoInmobiliarias;
import inmobiliarias.ActualizarInmobiliaria;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MenuUsuario extends JFrame {

    private JPanel menuUsuarioPanel;
    

    public MenuUsuario() {
    	
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 360);
        setLocationRelativeTo(null);
        
        

        menuUsuarioPanel = new JPanel();
        menuUsuarioPanel.setBackground(new Color(1, 26, 107));
        menuUsuarioPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
        menuUsuarioPanel.setLayout(null);
        
        int idUsuarioAutenticado = MenuPrincipal.getUsuarioAutenticado().getIdUsuario();
        
        // Crear un JLabel para mostrar el ID del usuario autenticado
        JLabel lblIdUsuario = new JLabel("Su ID Usuario: " + idUsuarioAutenticado);
        lblIdUsuario.setForeground(Color.WHITE);
        lblIdUsuario.setFont(new Font("Arial", Font.PLAIN, 12));
        lblIdUsuario.setBounds(10, 10, 100, 20); 
        menuUsuarioPanel.add(lblIdUsuario);
        
        
        JLabel titleMenu = new JLabel("MENÚ DE USUARIO");
		titleMenu.setForeground(new Color(255, 255, 255));
		titleMenu.setBackground(new Color(0, 6, 128));
		titleMenu.setFont(new Font("MV Boli", Font.PLAIN, 18));
		titleMenu.setHorizontalAlignment(SwingConstants.CENTER);
		titleMenu.setBounds(50, 20, 210, 56);
		menuUsuarioPanel.add(titleMenu);
        
        
        JButton btnActualizarPerfil = new JButton("Actualizar perfil");
        btnActualizarPerfil.setBounds(50, 100, 200, 40);
        btnActualizarPerfil.setFocusable(false);
        btnActualizarPerfil.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	 ActualizarUsuario actualizarUsuarioFrame = new ActualizarUsuario();
                 actualizarUsuarioFrame.setVisible(true);
            	 
            }
        });
        menuUsuarioPanel.add(btnActualizarPerfil);

        JButton btnVerListado = new JButton("Listado de inmuebles");
        btnVerListado.setBounds(50, 150, 200, 40);
        btnVerListado.setFocusable(false);
        btnVerListado.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	 ListadoInmuebles listadoInmueblesFrame = new ListadoInmuebles();
                 listadoInmueblesFrame.setVisible(true);
            }
        });
        menuUsuarioPanel.add(btnVerListado);

        


        JButton btnListaInmobiliaria = new JButton("Listado inmobiliarias");
        btnListaInmobiliaria.setBounds(50, 200, 200, 40);
        btnListaInmobiliaria.setFocusable(false);
        btnListaInmobiliaria.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	 ListadoInmobiliarias listadoInmobiliarias = new ListadoInmobiliarias();
                 listadoInmobiliarias.setVisible(true);
            }
        });
        menuUsuarioPanel.add(btnListaInmobiliaria);

       
        
        JButton btnActualizarInmobiliaria = new JButton("Actualizar inmobiliaria");
        btnActualizarInmobiliaria.setBounds(50, 250, 200, 40);
        btnActualizarInmobiliaria.setFocusable(false);
        btnActualizarInmobiliaria.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	 
            	 ListadoInmobiliarias listadoInmobiliarias = new ListadoInmobiliarias();
                 listadoInmobiliarias.setVisible(true);	
                 ActualizarInmobiliaria actualizarInmobiliariaFrame = new ActualizarInmobiliaria();
                 actualizarInmobiliariaFrame.setVisible(true);
            }
        });
        menuUsuarioPanel.add(btnActualizarInmobiliaria);
        

        setContentPane(menuUsuarioPanel);
        setVisible(true);
    }

}
