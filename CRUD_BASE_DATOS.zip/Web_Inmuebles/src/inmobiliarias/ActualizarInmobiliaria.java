package inmobiliarias;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import conexion.ConsultasBD;
import Gui.MenuPrincipal;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ActualizarInmobiliaria extends JFrame {

    private JPanel actualizarInmobiliariaPanel;
    private JTextField txtNuevoNombre;
    private JTextField txtNuevoEmail;
    private JTextField txtIdInmobiliaria;

    public ActualizarInmobiliaria() {
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);
        setTitle("ACTUALIZAR INMOBILIARIA");

        int idUsuarioAutenticado = MenuPrincipal.getUsuarioAutenticado().getIdUsuario();
        

        actualizarInmobiliariaPanel = new JPanel();
        actualizarInmobiliariaPanel.setBackground(new Color(1, 26, 107));
        actualizarInmobiliariaPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
        actualizarInmobiliariaPanel.setLayout(null);

        JLabel lblIdUsuario = new JLabel("Su ID Usuario: " + idUsuarioAutenticado);
        lblIdUsuario.setForeground(Color.WHITE);
        lblIdUsuario.setFont(new Font("Arial", Font.PLAIN, 12));
        lblIdUsuario.setBounds(10, 10, 150, 20);
        actualizarInmobiliariaPanel.add(lblIdUsuario);

        JLabel titleMenu = new JLabel("ACTUALIZAR INMOBILIARIA");
        titleMenu.setForeground(new Color(255, 255, 255));
        titleMenu.setBackground(new Color(0, 6, 128));
        titleMenu.setFont(new Font("MV Boli", Font.PLAIN, 18));
        titleMenu.setHorizontalAlignment(SwingConstants.CENTER);
        titleMenu.setBounds(40, 30, 260, 56);
        actualizarInmobiliariaPanel.add(titleMenu);
        
        JLabel lblIdInmobiliaria = new JLabel("ID inmobiliaria:");
        lblIdInmobiliaria.setBounds(40, 90, 100, 25);
        lblIdInmobiliaria.setForeground(new Color(255, 255, 255));
        actualizarInmobiliariaPanel.add(lblIdInmobiliaria);
        
        
        txtIdInmobiliaria = new JTextField();
        txtIdInmobiliaria.setBounds(160, 90, 100, 25);

        JLabel lblNuevoNombre = new JLabel("Nuevo Nombre:");
        lblNuevoNombre.setBounds(40, 130, 120, 25);
        lblNuevoNombre.setForeground(new Color(255, 255, 255));

        txtNuevoNombre = new JTextField();
        txtNuevoNombre.setBounds(160, 130, 100, 25);

        JLabel lblNuevoEmail = new JLabel("Nuevo Email:");
        lblNuevoEmail.setBounds(40, 170, 120, 25);
        lblNuevoEmail.setForeground(new Color(255, 255, 255));

        txtNuevoEmail = new JTextField();
        txtNuevoEmail.setBounds(160, 170, 100, 25);

        JButton btnActualizar = new JButton("Actualizar");
        btnActualizar.setBounds(160, 210, 100, 25);
        btnActualizar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nuevoNombre = txtNuevoNombre.getText();
                String nuevoEmail = txtNuevoEmail.getText();
                
                int idInmobiliaria = Integer.parseInt(txtIdInmobiliaria.getText());

                int idUsuarioAutenticado = MenuPrincipal.getUsuarioAutenticado().getIdUsuario();
                
                boolean tieneRelacion = ConsultasBD.tieneRelacionUsuarioInmobiliaria(idUsuarioAutenticado, idInmobiliaria);

                if (tieneRelacion) {
                    ConsultasBD.actualizarInmobiliaria(idInmobiliaria, nuevoNombre, nuevoEmail);
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "No tiene permisos para actualizar esta inmobiliaria.");
                }
            }
        });


        actualizarInmobiliariaPanel.add(lblIdInmobiliaria);
        actualizarInmobiliariaPanel.add(txtIdInmobiliaria);
        actualizarInmobiliariaPanel.add(lblNuevoNombre);
        actualizarInmobiliariaPanel.add(txtNuevoNombre);
        actualizarInmobiliariaPanel.add(lblNuevoEmail);
        actualizarInmobiliariaPanel.add(txtNuevoEmail);
        actualizarInmobiliariaPanel.add(btnActualizar);

        setContentPane(actualizarInmobiliariaPanel);
        setVisible(true);
    }
}
