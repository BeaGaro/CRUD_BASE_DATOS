package inmobiliarias;

import javax.swing.*;
import java.awt.*;
import conexion.ConsultasBD;

public class ListadoInmobiliarias extends JFrame {
    private JPanel listadoInmobiliariasPanel;
    private JTable table;
    
    

    public ListadoInmobiliarias() {
        setTitle("LISTADO DE INMOBILIARIAS");
        setSize(600, 400);
        setLocationRelativeTo(null);

        listadoInmobiliariasPanel = new JPanel(new BorderLayout());
        listadoInmobiliariasPanel.setBackground(new Color(1, 26, 107)); 

        // Crear la tabla donde se cargarán los datos
        table = new JTable();

        // Lógica para obtener los datos de las inmobiliarias desde la base de datos y cargarlos en la tabla
        ConsultasBD consultasBD = new ConsultasBD();
        consultasBD.cargarInmobiliarias(table);

        // Agregar la tabla a un JScrollPane y al panel
        JScrollPane scrollPane = new JScrollPane(table);
        listadoInmobiliariasPanel.add(scrollPane, BorderLayout.CENTER);

        // Agregar el panel al JFrame
        add(listadoInmobiliariasPanel);
        setVisible(true);
    }
}
