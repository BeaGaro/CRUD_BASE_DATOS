package inmobiliarias;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import conexion.ConsultasBD;

public class AñadirInmobiliaria extends JFrame {
    private JPanel añadirInmobiliariaPanel;
    private JTextField txtNombre;
    private JTextField txtEmail;
    private JTextField txtIdUsuario;

    public AñadirInmobiliaria() {
        setTitle("Añadir Inmobiliaria");
        setSize(400, 200);
        setLocationRelativeTo(null);

        añadirInmobiliariaPanel = new JPanel(null); 
        añadirInmobiliariaPanel.setBackground(new Color(1, 26, 107));
        añadirInmobiliariaPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
        añadirInmobiliariaPanel.setLayout(null);
        
        
        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(20, 20, 80, 25);
        lblNombre.setForeground(new Color(255, 255, 255));
        
        txtNombre = new JTextField();
        txtNombre.setBounds(120, 20, 200, 25);
        
        JLabel lblEmail = new JLabel("Email:");
        lblEmail.setForeground(new Color(255, 255, 255));
        lblEmail.setBounds(20, 50, 80, 25);
        
        txtEmail = new JTextField();
        txtEmail.setBounds(120, 50, 200, 25);
        
        JLabel lblIdUsuario = new JLabel("ID Usuario:");
        lblIdUsuario.setForeground(new Color(255, 255, 255));     
        lblIdUsuario.setBounds(20, 80, 80, 25);
        
        txtIdUsuario = new JTextField();
        txtIdUsuario.setBounds(120, 80, 200, 25);

        JButton btnGuardar = new JButton("Guardar");
        btnGuardar.setBounds(120, 120, 100, 30);

        añadirInmobiliariaPanel.add(lblNombre);
        añadirInmobiliariaPanel.add(txtNombre);
        añadirInmobiliariaPanel.add(lblEmail);
        añadirInmobiliariaPanel.add(txtEmail);
        añadirInmobiliariaPanel.add(lblIdUsuario);
        añadirInmobiliariaPanel.add(txtIdUsuario);
        añadirInmobiliariaPanel.add(btnGuardar);

        btnGuardar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                // Obtener los datos ingresados por el usuario
                String nombre = txtNombre.getText();
                String email = txtEmail.getText();
                int idUsuario = Integer.parseInt(txtIdUsuario.getText());

                // Lógica para agregar una inmobiliaria a la base de datos
                ConsultasBD consultasBD = new ConsultasBD();
                consultasBD.agregarInmobiliaria(nombre, email, idUsuario);

                // Cerrar la ventana después de agregar
                dispose();
            }
        });

        add(añadirInmobiliariaPanel);
        setVisible(true);
    }
}
